insert into integrations
( server_id,
  integration_id,
  integration_type,
  integration_user_info ) 
values 
( :server_id:,
  :integration_id:,
  :integration_type:,
  :integration_user_info: );